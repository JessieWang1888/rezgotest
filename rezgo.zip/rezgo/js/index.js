﻿  // get json file

function getdata(callback) {
    $.getJSON('js/awesome.json', function(data) {
        callback(data);
    });
}
  // close detail pop
  // hide black mask
  // scroll to top
function closepopout() {
    $(".itemdetail").hide();
    $(".mask").hide();
    window.scrollTo(0, 0);
}

  // create item lsit 

getdata(function(data) {

    console.log(data);
    var totalitem = data.total;
    console.log(totalitem);
    var itemname = data.item[0].details.description_name;
    console.log(itemname);
    for (i = 0; i < totalitem; i++) {
        $(".itemlist").append("<li id=\"item" + data.item[i].uid + "\" class=\"row itemlist-item\"><div class=\"item-thumbnail col-sm-4\"><img  src=" + data.item[i].media.image['0'].path + " /></div><div class=\"col col-sm-8 itembrief\"><h5>" + data.item[i].item + "</h5><p class=\"rate\">" + data.item[i].rating + "/5</p><div class=\"ellipsis\">" + data.item[i].details.overview + "</div><div class=\"location\"><p><span>Location:</span>" + data.item[i].location_address + "</p></div><div class=\"price\"><p><span>Start From:</span>" + data.item[i].currency_symbol + data.item[i].starting + "</p></div><button onclick=\"itemdetail(" + i + ");\">Learn More</button></div></li>");
        // hide content after character 
        $(".ellipsis").each(function() {
            var text = jQuery(this).text();
            if (text.length > 150) {
                jQuery(this).text(text.substr(0, text.lastIndexOf(' ', 147)) + '...');
            }
        });
    }
});

  // check which learn more btn has been click and create the detail page for that item
function itemdetail(num) {

    $.getJSON("js/awesome.json", function(listdata) {
        var listdata;
        console.log(listdata);
        console.log(num);
        var currentitem = listdata.item[num]
        var totalimage = currentitem.media.image;
        console.log(totalimage);
        console.log(totalimage.length);
        $(".carousel-inner").empty();
        $(".carousel-indicators").empty();
        $(".title").empty();
        $(".itempagedetail").empty();
        $(".title").append(currentitem.item);
        $(".itempagedetail").append("<p><span>Location:</span>" + currentitem.details.location_name + currentitem.location_address + "</p><p><span>Price:</span>" + currentitem.currency_symbol + currentitem.starting + "</p><p><span>Description:</span>" + currentitem.details.description + "</p><p><span>Overview:</span>" + currentitem.details.overview + "</p><p><span>Pick up:</span>" + currentitem.details.pick_up + "</p><p><span>Drop off:</span>" + currentitem.details.drop_off + "</p> <button class=\"closebtn\" onclick=\"closepopout();\">Close</button>");
        for (i = 0; i < totalimage.length; i++) {
            $(".carousel-indicators").append(" <li data-target=\"#carouselExampleIndicators\" data-slide-to=" + i + "></li> ");
            $(".carousel-indicators li").first().addClass("active");
            $(".carousel-inner").append("<div class=\"carousel-item \">  <img class=\"d-block w-100\" src=" + totalimage[i].path + " ></div>");
            $(".carousel-item").first().addClass("active");
        }



        // show detail pop and black mask 
        $(".itemdetail").show();
        $(".mask").show();

    });

}